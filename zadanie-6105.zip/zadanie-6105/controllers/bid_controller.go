package controllers

import (
	"ZADANIE-6105/models"
	"ZADANIE-6105/utils"
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
	"gorm.io/gorm"
)

type BidController struct {
	DB *gorm.DB
}

// Create a new bid
func (bc *BidController) CreateBid(w http.ResponseWriter, r *http.Request) {
	var bid models.Bid
	if err := json.NewDecoder(r.Body).Decode(&bid); err != nil {
		utils.RespondError(w, http.StatusBadRequest, "Invalid request payload")
		return
	}
	bid.Status = models.BidCreated
	if err := bc.DB.Create(&bid).Error; err != nil {
		utils.RespondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	utils.RespondJSON(w, http.StatusCreated, bid)
}

// Edit an existing bid
func (bc *BidController) EditBid(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	bidID, err := strconv.Atoi(params["bidId"])
	if err != nil {
		utils.RespondError(w, http.StatusBadRequest, "Invalid bid ID")
		return
	}

	var bid models.Bid
	if err := bc.DB.First(&bid, bidID).Error; err != nil {
		utils.RespondError(w, http.StatusNotFound, "Bid not found")
		return
	}

	var updatedBid models.Bid
	if err := json.NewDecoder(r.Body).Decode(&updatedBid); err != nil {
		utils.RespondError(w, http.StatusBadRequest, "Invalid request payload")
		return
	}

	// Use a transaction for versioning and updating
	err = bc.DB.Transaction(func(tx *gorm.DB) error {
		// Save current version
		bidVersion := models.BidVersion{
			BidID:       bid.ID,
			Version:     bid.Version,
			Name:        bid.Name,
			Description: bid.Description,
			CreatedAt:   bid.UpdatedAt,
		}
		if err := tx.Create(&bidVersion).Error; err != nil {
			return err
		}

		// Update bid
		bid.Name = updatedBid.Name
		bid.Description = updatedBid.Description
		bid.Version += 1
		return tx.Save(&bid).Error
	})

	if err != nil {
		utils.RespondError(w, http.StatusInternalServerError, "Failed to update bid")
		return
	}

	utils.RespondJSON(w, http.StatusOK, bid)
}

// Rollback a bid to a specific version
func (bc *BidController) RollbackBid(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	bidID, err := strconv.Atoi(params["bidId"])
	if err != nil {
		utils.RespondError(w, http.StatusBadRequest, "Invalid bid ID")
		return
	}

	version, err := strconv.Atoi(params["version"])
	if err != nil {
		utils.RespondError(w, http.StatusBadRequest, "Invalid version number")
		return
	}

	var bid models.Bid
	if err := bc.DB.First(&bid, bidID).Error; err != nil {
		utils.RespondError(w, http.StatusNotFound, "Bid not found")
		return
	}

	var bidVersion models.BidVersion
	if err := bc.DB.Where("bid_id = ? AND version = ?", bidID, version).First(&bidVersion).Error; err != nil {
		utils.RespondError(w, http.StatusNotFound, "Version not found")
		return
	}

	// Update bid to the selected version
	bid.Name = bidVersion.Name
	bid.Description = bidVersion.Description
	bid.Version = bidVersion.Version + 1 // Increment version after rollback
	if err := bc.DB.Save(&bid).Error; err != nil {
		utils.RespondError(w, http.StatusInternalServerError, "Failed to rollback bid")
		return
	}

	utils.RespondJSON(w, http.StatusOK, bid)
}

// Retrieve bids created by a specific user
func (bc *BidController) GetMyBids(w http.ResponseWriter, r *http.Request) {
	username := r.URL.Query().Get("username")
	if username == "" {
		utils.RespondError(w, http.StatusBadRequest, "Username is required")
		return
	}

	var bids []models.Bid
	err := bc.DB.Where("creator_username = ?", username).Find(&bids).Error
	if err != nil {
		utils.RespondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusOK, bids)
}
